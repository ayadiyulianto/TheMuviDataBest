package com.ayadiyulianto.themuvidatabest.core.domain.model

data class TvShowWithSeason(
    var tvShow: TvShow,
    var seasons: List<Season>
)
